/*
	Copyright(c) 2021-2026 jvde.github@gmail.com

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <string>
#include <thread>

#include "ReceiverTracker.h"

class BackupManager
{
	std::thread thread;
	std::mutex mtx;
	std::condition_variable cv;
	std::atomic<bool> running{false};
	int interval = -1;
	std::string filename;
	ReceiverTracker *tracker = nullptr;

	void run();

public:
	void setInterval(int minutes) { interval = minutes; }
	void setFilename(const std::string &f) { filename = f; }
	void resetSettings()
	{
		interval = -1;
		filename.clear();
	}
	const std::string &getFilename() const { return filename; }
	void setTracker(ReceiverTracker *t) { tracker = t; }

	void start();
	void stop();
	bool save(bool include_ships = true);
	bool load();

	~BackupManager() { stop(); }
};
