/*
	Copyright(c) 2024 - 2026 jvde.github@gmail.com

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <cstring>

#include "Serial.h"
#include "Helper.h"

#ifndef _WIN32
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <limits.h>
#endif

namespace
{
#ifndef _WIN32
	// Helper for POSIX serial write with CR and drain
	void WriteSerialCommand(int fd, const std::string &cmd)
	{
		std::string out = cmd + "\r";
		if (write(fd, out.c_str(), out.length()) < 0)
		{
			throw std::runtime_error("Serial: failed to send command: '" + cmd + "'.");
		}
		tcdrain(fd);
	}
#else
	// Helper for Windows serial write with CR and flush
	void WriteSerialCommand(HANDLE handle, const std::string &cmd)
	{
		std::string out = cmd + "\r";
		DWORD bytesWritten;
		if (!WriteFile(handle, out.c_str(), out.length(), &bytesWritten, nullptr))
		{
			throw std::runtime_error("Serial: failed to send command: '" + cmd + "'.");
		}
		FlushFileBuffers(handle);
	}
#endif
}

namespace Device
{
	std::vector<std::string> SerialPort::device_list;
	std::mutex SerialPort::list_mtx;

	void SerialPort::ReadAsync()
	{

		char buffer[16384];
		RAW r = {getFormat(), buffer, 0};

#ifdef _WIN32
		Debug() << "Serial: starting thread";
		DWORD bytesRead;

		while (isStreaming())
		{
			if (ReadFile(serial_handle, buffer, sizeof(buffer), &bytesRead, nullptr))
			{
				if (bytesRead > 0)
				{
					r.size = bytesRead;
					Dump(r);
					Send(&r, 1, tag);
				}
				else
				{
					SleepSystem(100);
				}
			}
			else
			{
				DWORD error = GetLastError();
				Error() << "Serial read error: " << error;
				lost = true;
				break;
			}
		}
#else

		while (isStreaming())
		{
			fd_set read_fds;

			FD_ZERO(&read_fds);
			FD_SET(serial_fd, &read_fds);

			struct timeval timeout = {1, 0};

			int rslt = select(serial_fd + 1, &read_fds, NULL, NULL, &timeout);
			if (rslt > 0)
			{
				int nread = read(serial_fd, buffer, sizeof(buffer));
				if (nread > 0)
				{
					r.size = nread;
					Dump(r);
					Send(&r, 1, tag);
				}
				else
				{
					if (nread == 0)
					{
						Error() << "Serial read encountered an error: unexpected end.";
					}
					else
					{
						Error() << "Serial read encountered an error: " << strerror(errno);
					}
					lost = true;
				}
			}
			else if (rslt < 0)
			{
				Error() << "Serial read encountered an error: " << strerror(errno);
				lost = true;
			}
		}
#endif
	}

	void SerialPort::Dump(RAW &r)
	{
		if (dump)
		{
			if (dump_stream.is_open())
			{
				dump_stream.write((const char *)r.data, r.size);
				return;
			}

			std::cerr << ">> ";
			for (int i = 0; i < r.size; i++)
			{
				char c = ((char *)r.data)[i];
				if (c != '\n' && c != '\r')
					std::cerr << c;
			}
			std::cerr << std::endl;
		}
	}

	SerialPort::~SerialPort()
	{
		Close();
	}

	void SerialPort::Close()
	{
		if (dump_stream.is_open())
			dump_stream.close();

#ifdef _WIN32
		if (serial_handle != INVALID_HANDLE_VALUE)
		{
			CloseHandle(serial_handle);
			serial_handle = INVALID_HANDLE_VALUE;
		}
#else
		if (serial_fd != -1)
		{
			close(serial_fd);
			serial_fd = -1;
		}
#endif
	}

	void SerialPort::Open(uint64_t handle)
	{
		if (port.empty())
		{
			std::lock_guard<std::mutex> lock(list_mtx);
			if (handle < device_list.size())
			{
				port = device_list[handle];
			}
			else
			{
				throw std::runtime_error("Serial: Invalid device handle " + std::to_string(handle));
			}
		}
	}

	void SerialPort::Play()
	{
		if (dump && !dump_file.empty())
		{
			dump_stream.close();
			dump_stream.open(dump_file, std::ios::out | std::ios::app);
			if (!dump_stream.is_open())
			{
				throw std::runtime_error("Serial: cannot open dump file \"" + dump_file + "\".");
			}
		}

#ifdef _WIN32
		switch (baudrate)
		{
		case 9600:
		case 19200:
		case 38400:
		case 57600:
		case 115200:
			break;
		default:
			throw std::runtime_error("Serial: unsupported baudrate.");
		}

		serial_handle = CreateFileA(port.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
		if (serial_handle == INVALID_HANDLE_VALUE)
		{
			throw std::runtime_error("Serial: cannot open serial port " + port + ". Error: " + GetLastErrorAsString());
		}

		DCB dcb;
		if (GetCommState(serial_handle, &dcb))
		{
			dcb.BaudRate = baudrate;
			dcb.ByteSize = 8;
			dcb.Parity = NOPARITY;
			dcb.StopBits = ONESTOPBIT;
			dcb.fBinary = TRUE;
			dcb.fParity = TRUE;
			dcb.fDtrControl = DTR_CONTROL_ENABLE;
			dcb.fRtsControl = RTS_CONTROL_ENABLE;
			dcb.fOutX = FALSE; // Disable XON/XOFF output flow control
			dcb.fInX = FALSE;  // Disable XON/XOFF input flow control
		}
		else
			throw std::runtime_error("Serial: GetCommState failed. Error: " + GetLastErrorAsString());

		if (!SetCommState(serial_handle, &dcb))
		{
			throw std::runtime_error("Serial: SetCommState failed. Error: " + GetLastErrorAsString());
		}

		// Set timeouts for immediate return with available data
		COMMTIMEOUTS ct = {0};
		ct.ReadIntervalTimeout = MAXDWORD; // Return immediately
		ct.ReadTotalTimeoutMultiplier = 0;
		ct.ReadTotalTimeoutConstant = 0;
		ct.WriteTotalTimeoutConstant = 2000; // write timeout
		ct.WriteTotalTimeoutMultiplier = 0;

		if (!SetCommTimeouts(serial_handle, &ct))
			throw std::runtime_error("Serial: SetCommTimeouts failed. Error: " + GetLastErrorAsString());

		if (init_sequence.length())
		{
			SleepSystem(100);
			// Send initial carriage return (empty command)
			WriteSerialCommand(serial_handle, "");

			// Split by comma and send each command separately
			std::stringstream ss(init_sequence);
			std::string cmd;

			while (std::getline(ss, cmd, ','))
			{
				SleepSystem(250);
				if (!cmd.empty())
				{
					WriteSerialCommand(serial_handle, cmd);
					Info() << "Serial: init command sent \"" << cmd << "\"";
				}
			}
		}
#else
		// Open with O_NONBLOCK to avoid blocking on DTR
		serial_fd = open(port.c_str(), O_RDWR | O_NOCTTY | O_CLOEXEC | O_NONBLOCK);
		if (serial_fd == -1)
		{
			throw std::runtime_error("Failed to open serial port " + port + " at baudrate " + std::to_string(baudrate) + ".");
		}

		// Clear O_NONBLOCK after opening to allow normal blocking behavior for reads
		int flags = fcntl(serial_fd, F_GETFL);
		if (flags != -1)
		{
			fcntl(serial_fd, F_SETFL, flags & ~O_NONBLOCK);
		}

		struct termios tty;
		if (tcgetattr(serial_fd, &tty) < 0)
		{
			throw std::runtime_error(std::string("Serial: tcgetattr failed: ") + strerror(errno));
		}

		speed_t brc = B9600;
		switch (baudrate)
		{
		case 9600:
			brc = B9600;
			break;
		case 19200:
			brc = B19200;
			break;
		case 38400:
			brc = B38400;
			break;
		case 57600:
			brc = B57600;
			break;
		case 115200:
			brc = B115200;
			break;
		default:
			throw std::runtime_error("Serial: unsupported baudrate.");
		}

		if (cfsetospeed(&tty, brc) < 0)
		{
			throw std::runtime_error(std::string("Serial: cfsetospeed failed: ") + strerror(errno));
		}

		if (cfsetispeed(&tty, brc) < 0)
		{
			throw std::runtime_error(std::string("Serial: cfsetispeed failed: ") + strerror(errno));
		}

		// Set 8N1, raw mode
		tty.c_cflag = (tty.c_cflag & ~(CSIZE | CSTOPB | PARENB | PARODD)) | (CREAD | CLOCAL | CS8);
		tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ECHOK | ECHONL | ISIG | IEXTEN);
		tty.c_oflag &= ~OPOST;
		tty.c_iflag &= ~(INLCR | IGNCR | ICRNL | IGNBRK | INPCK | ISTRIP);
#ifdef IUCLC
		tty.c_iflag &= ~IUCLC;
#endif
#ifdef PARMRK
		tty.c_iflag &= ~PARMRK;
#endif

		// Flow control
		if (flowcontrol == FlowControl::HARDWARE)
		{
			tty.c_cflag |= CRTSCTS;
			Info() << "Serial: hardware flow control enabled";
		}
		else
		{
			tty.c_cflag &= ~CRTSCTS;
		}

#ifdef IXANY
		tty.c_iflag = (flowcontrol == FlowControl::SOFTWARE) ? ((tty.c_iflag | (IXON | IXOFF)) & ~IXANY) : (tty.c_iflag & ~(IXON | IXOFF | IXANY));
#else
		tty.c_iflag = (flowcontrol == FlowControl::SOFTWARE) ? (tty.c_iflag | (IXON | IXOFF)) : (tty.c_iflag & ~(IXON | IXOFF));
#endif
		if (flowcontrol == FlowControl::SOFTWARE)
			Info() << "Serial: software flow control enabled";

		tty.c_cc[VMIN] = 1;
		tty.c_cc[VTIME] = 0;

		if (tcsetattr(serial_fd, TCSANOW, &tty) < 0)
		{
			throw std::runtime_error(std::string("Serial: tcsetattr failed: ") + strerror(errno));
		}

		SleepSystem(200);
		tcflush(serial_fd, TCIOFLUSH);

		int status;
		if (ioctl(serial_fd, TIOCMGET, &status) == 0)
		{
			status |= TIOCM_DTR | TIOCM_RTS;
			ioctl(serial_fd, TIOCMSET, &status);
			SleepSystem(100);
		}

		if (init_sequence.length())
		{
			SleepSystem(100);
			WriteSerialCommand(serial_fd, "");

			std::stringstream ss(init_sequence);
			std::string cmd;
			while (std::getline(ss, cmd, ','))
			{
				if (!cmd.empty())
				{
					SleepSystem(250);
					Info() << "Serial: init command sent \"" << cmd << "\"";
					WriteSerialCommand(serial_fd, cmd);
				}
			}
		}
#endif

		Device::Play();

		lost = false;
		read_thread = std::thread(&SerialPort::ReadAsync, this);
	}
	void SerialPort::Stop()
	{
		lost = true;
		if (read_thread.joinable())
		{
			read_thread.join();
		}

		if (dump_stream.is_open())
			dump_stream.close();
	}

	Setting &SerialPort::SetKey(AIS::Keys key, const std::string &arg)
	{
		switch (key)
		{
		case AIS::KEY_SETTING_BAUDRATE:
			baudrate = Util::Parse::Integer(arg);
			break;
		case AIS::KEY_SETTING_PORT:
		{
			std::string p = arg;
#ifdef _WIN32
			if (p.size() == 5 && std::toupper(p[0]) == 'C' && std::toupper(p[1]) == 'O' && std::toupper(p[2]) == 'M' && std::isdigit(p[3]) && std::isdigit(p[4]))
			{
				p = "\\\\.\\" + p;
				Warning() << "Serial: using Windows COM port format: " << p;
			}
#endif
			port = p;
			break;
		}
		case AIS::KEY_SETTING_PRINT:
			Warning() << "PRINT option is deprecated and will be removed in a future release. Use DUMP instead.";
			dump = Util::Parse::Switch(arg);
			break;
		case AIS::KEY_SETTING_DUMP:
			dump = Util::Parse::Switch(arg);
			break;
		case AIS::KEY_SETTING_DUMP_FILE:
			dump_file = arg;
			dump = true;
			break;
		case AIS::KEY_SETTING_SERIAL_INIT_SEQUENCE:
			init_sequence = arg;
			break;
		case AIS::KEY_SETTING_DISABLE_XONXOFF:
			throw std::runtime_error("Serial: DISABLE_XONXOFF option is deprecated. Use FLOWCONTROL instead.");
			break;
		case AIS::KEY_SETTING_FLOWCONTROL:
		{
			std::string a = arg;
			Util::Convert::toUpper(a);
			if (a == "NONE")
				flowcontrol = FlowControl::NONE;
			else if (a == "HARDWARE")
				flowcontrol = FlowControl::HARDWARE;
			else if (a == "SOFTWARE")
				flowcontrol = FlowControl::SOFTWARE;
			else
				throw std::runtime_error("Serial: invalid flowcontrol option: \"" + arg + "\". Valid options are NONE, HARDWARE, SOFTWARE.");
			break;
		}
		default:
			Device::SetKey(key, arg);
			break;
		}
		return *this;
	}

	std::string SerialPort::Get()
	{
		std::string fc_str;
		switch (flowcontrol)
		{
		case FlowControl::NONE:
			fc_str = "none";
			break;
		case FlowControl::HARDWARE:
			fc_str = "hardware";
			break;
		case FlowControl::SOFTWARE:
			fc_str = "software";
			break;
		}

		return Device::Get() +
			   " baudrate " + std::to_string(baudrate) +
			   " flowcontrol " + fc_str +
			   " port " + port +
			   " dump " + Util::Convert::toString(dump) +
			   (!dump_file.empty() ? (" dump_file " + dump_file) : "");
	}
	void SerialPort::getDeviceList(std::vector<Description> &DeviceList)
	{
		std::lock_guard<std::mutex> lock(list_mtx);
		device_list.clear();

#if defined(__APPLE__)
		// macOS exposes serial ports as /dev/cu.*
		std::vector<std::string> dev_files = Util::Helper::getFilesInDirectory("/dev");
		for (const auto &name : dev_files)
		{
			if (name.compare(0, 3, "cu.") != 0 || name.find("Bluetooth") != std::string::npos)
				continue;

			std::string device_path = "/dev/" + name;

			uint64_t handle = device_list.size();
			device_list.push_back(device_path);
			DeviceList.push_back(Description("Serial", "USB Serial", name, handle, Type::SERIALPORT));
		}
#elif !defined(_WIN32)
		// Scan /dev/serial/by-id for persistent device names (symlinks)
		std::vector<std::string> by_id_files = Util::Helper::getFilesInDirectory("/dev/serial/by-id");
		for (const auto &name : by_id_files)
		{
			std::string device_path = "/dev/serial/by-id/" + name;

			uint64_t handle = device_list.size();
			device_list.push_back(device_path);
			DeviceList.push_back(Description("Serial", "USB Serial", name, handle, Type::SERIALPORT));
		}
#endif
	}
}
