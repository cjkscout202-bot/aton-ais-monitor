/*
	Copyright(c) 2021-2026 jvde.github@gmail.com

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once

#include <string>
#include <unordered_map>
#include <mutex>
#include <ctime>

#include "HTTPServer.h"
#include "ControlCore.h"

class ControlServer : public IO::HTTPServer
{
public:
	ControlServer(ControlCore &core) : core(core)
	{
		setFrameSrc("'self' http: https:");
	}
	~ControlServer() { close(); }

	void start();
	void close();

	void Request(IO::TCPServerConnection &c, const IO::HTTPRequest &r, bool accept_gzip) override;

protected:
	void processClients() override;

private:
	ControlCore &core;

	// The endpoints that answer without a session, method null meaning any.
	// Everything else is private: a mistake here locks an endpoint down
	// rather than exposing it.
	struct PublicEndpoint
	{
		const char *path;
		const char *method;
	};

	static const PublicEndpoint public_endpoints[];
	static bool isPublic(const std::string &path, const std::string &method);

	// serve the bundled control frontend, or 404
	void serveStatic(IO::TCPServerConnection &c, const std::string &path);
	static std::string cookieAttributes();

	static const int SSE_ACTIVITY = 1;
	static const int SSE_STATUS = 2;
	static const int SSE_LOG = 3;

	static const int SESSION_LIFETIME = 7 * 24 * 3600;
	static const int MAX_LOGIN_BLOCK = 300;

	std::mutex auth_mtx;
	std::unordered_map<std::string, std::time_t> sessions;
	int login_failures = 0;
	std::time_t login_block_until = 0;

	int log_listener = -1;

	uint32_t activity_sent[4] = {0, 0, 0, 0};
	std::time_t activity_time = 0;

	static const uint32_t STATUS_UNSENT = 0xFFFFFFFF;
	uint32_t status_state = STATUS_UNSENT;

	std::string createSession();
	bool checkSession(const std::string &cookie);
	void destroySession(const std::string &cookie);
	void destroyAllSessions();
	static std::string sessionFromCookie(const std::string &cookie);

	static bool sameOrigin(const IO::HTTPRequest &r);

	bool loginBlocked(int &seconds_left);
	void loginFailed();
	void loginSucceeded();

	std::string statusJSON(const char *auth, bool authenticated);
	void sendStatus(IO::TCPServerConnection &c, bool authenticated);
	void sendOK(IO::TCPServerConnection &c);
	void sendError(IO::TCPServerConnection &c, const std::string &message, int status = 400);
};
