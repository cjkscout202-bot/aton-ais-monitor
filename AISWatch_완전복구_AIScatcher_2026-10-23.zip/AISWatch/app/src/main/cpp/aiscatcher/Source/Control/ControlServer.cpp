/*
	Copyright(c) 2021-2026 jvde.github@gmail.com

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "AIS-catcher.h"
#include "ControlServer.h"
#include "Logger.h"
#include "Writer.h"
#include "Convert.h"
#include "WebDB.h"
#include "Helper.h"

void ControlServer::start()
{
	if (core.getBindAddress() != "0.0.0.0")
		setIP(core.getBindAddress());

	if (!HTTPServer::start(core.getControlPort()))
		throw std::runtime_error("Control: cannot start control server at port " + std::to_string(core.getControlPort()));

	log_listener = Logger::getInstance().addLogListener([this](const LogMessage &m)
														{ sendSSE(SSE_LOG, "log", m.toJSON()); });

	Info() << "Control: control server running at port " << core.getControlPort();
}

void ControlServer::processClients()
{
	HTTPServer::processClients();

	if (hasSSEClients())
	{
		uint32_t stamp = core.statusStamp();
		if (stamp != status_state)
		{
			status_state = stamp;
			sendSSE(SSE_STATUS, "status", statusJSON(nullptr, false));
		}
	}

	std::time_t now = std::time(nullptr);
	if (now == activity_time)
		return;

	uint32_t snapshot[4];
	bool changed = false;
	for (int i = 0; i < 4; i++)
	{
		snapshot[i] = core.getChannelActivity().count[i];
		changed |= snapshot[i] != activity_sent[i];
	}

	if (!changed)
		return;

	activity_time = now;

	std::string s = "[";
	for (int i = 0; i < 4; i++)
		s += std::to_string(snapshot[i]) + (i < 3 ? "," : "]");

	for (int i = 0; i < 4; i++)
		activity_sent[i] = snapshot[i];

	sendSSE(SSE_ACTIVITY, "activity", s);
}

void ControlServer::close()
{
	if (log_listener >= 0)
	{
		Logger::getInstance().removeLogListener(log_listener);
		log_listener = -1;
	}
	stopThread();
}

std::string ControlServer::createSession()
{
	std::string token = ControlCore::randomHex(48);

	std::lock_guard<std::mutex> lock(auth_mtx);

	std::time_t now = std::time(nullptr);
	for (auto it = sessions.begin(); it != sessions.end();)
	{
		if (it->second < now)
			it = sessions.erase(it);
		else
			++it;
	}

	sessions[token] = now + SESSION_LIFETIME;
	return token;
}

std::string ControlServer::sessionFromCookie(const std::string &cookie)
{
	const std::string name = "aiscontrol=";

	std::string::size_type pos = 0;
	while ((pos = cookie.find(name, pos)) != std::string::npos)
	{
		if (pos == 0 || cookie[pos - 1] == ' ' || cookie[pos - 1] == ';')
		{
			std::string::size_type start = pos + name.length();
			std::string::size_type end = cookie.find(';', start);
			return cookie.substr(start, end == std::string::npos ? std::string::npos : end - start);
		}
		pos += name.length();
	}
	return "";
}

bool ControlServer::checkSession(const std::string &cookie)
{
	std::string token = sessionFromCookie(cookie);
	if (token.empty())
		return false;

	std::lock_guard<std::mutex> lock(auth_mtx);

	auto it = sessions.find(token);
	if (it == sessions.end())
		return false;

	std::time_t now = std::time(nullptr);
	if (it->second < now)
	{
		sessions.erase(it);
		return false;
	}

	it->second = now + SESSION_LIFETIME;
	return true;
}

void ControlServer::destroySession(const std::string &cookie)
{
	std::lock_guard<std::mutex> lock(auth_mtx);
	sessions.erase(sessionFromCookie(cookie));
}

void ControlServer::destroyAllSessions()
{
	std::lock_guard<std::mutex> lock(auth_mtx);
	sessions.clear();
}

bool ControlServer::loginBlocked(int &seconds_left)
{
	std::lock_guard<std::mutex> lock(auth_mtx);

	std::time_t now = std::time(nullptr);
	if (login_block_until > now)
	{
		seconds_left = (int)(login_block_until - now);
		return true;
	}
	return false;
}

void ControlServer::loginFailed()
{
	std::lock_guard<std::mutex> lock(auth_mtx);

	login_failures++;
	int block = 1 << MIN(login_failures, 8);
	login_block_until = std::time(nullptr) + MIN(block, MAX_LOGIN_BLOCK);
}

void ControlServer::loginSucceeded()
{
	std::lock_guard<std::mutex> lock(auth_mtx);
	login_failures = 0;
	login_block_until = 0;
}

std::string ControlServer::statusJSON(const char *auth, bool authenticated)
{
	bool running = core.getEngineState() == ControlCore::EngineState::Running;

	std::string s;
	JSON::Writer w(s);
	w.beginObject();

	if (auth)
		w.kv("auth", auth);
		
	w.kv("engine", running ? "running" : "stopped")
		.kv("desired", core.engineDesired())
		.kv("retrying", core.engineRetrying())
		.kv("uptime", core.getUptime())
		.kv("viewer", core.getViewerPort())
		.kv("wizard", core.wizardPending());

	if (authenticated)
	{
		static const std::string os = Util::Helper::getOS();
		static const std::string hardware = Util::Helper::getHardware();

		w.kv("has_password", core.hasPassword())
			.kv("version", VERSION_DESCRIBE)
			.kv("build_date", __DATE__)
			.kv("os", os)
			.kv("hardware", hardware)
			.kv("memory", (unsigned long long)Util::Helper::getMemoryConsumption());
	}

	w.endObject().finish();
	return s;
}

void ControlServer::sendStatus(IO::TCPServerConnection &c, bool authenticated)
{
	const char *auth = !core.authRequired()	 ? "open"
					   : !core.hasPassword() ? (authenticated ? "ok" : "setup")
					   : c.is_local			 ? "open"
											 : (authenticated ? "ok" : "login");

	Response(c, "application/json", statusJSON(auth, authenticated));
}

void ControlServer::sendOK(IO::TCPServerConnection &c)
{
	Response(c, "application/json", std::string("{\"status\":true}"));
}

void ControlServer::sendError(IO::TCPServerConnection &c, const std::string &message, int status)
{
	std::string s;
	JSON::Writer w(s);
	w.beginObject().kv("status", false).kv("error", message).endObject().finish();
	Response(c, "application/json", s, false, false, false, status);
}

bool ControlServer::sameOrigin(const IO::HTTPRequest &r)
{
	if (r.origin.empty())
		return true;

	auto host = [](std::string h) -> std::string
	{
		if (h.compare(0, 7, "http://") == 0)
			h = h.substr(7);
		else if (h.compare(0, 8, "https://") == 0)
			h = h.substr(8);

		if (h.size() > 3 && h.compare(h.size() - 3, 3, ":80") == 0)
			return h.substr(0, h.size() - 3);
		if (h.size() > 4 && h.compare(h.size() - 4, 4, ":443") == 0)
			return h.substr(0, h.size() - 4);
		return h;
	};

	const std::string origin = host(r.origin);

	return origin == host(r.host) ||
		   (!r.forwarded_host.empty() && origin == host(r.forwarded_host));
}

std::string ControlServer::cookieAttributes()
{
	return "; Path=/; Max-Age=" + std::to_string(SESSION_LIFETIME) + "; HttpOnly; SameSite=Strict";
}

const ControlServer::PublicEndpoint ControlServer::public_endpoints[] = {
	{"/api/status", nullptr},
	{"/api/setup", "POST"},
	{"/api/login", "POST"},
	{nullptr, nullptr}};

bool ControlServer::isPublic(const std::string &path, const std::string &method)
{
	for (const PublicEndpoint *e = public_endpoints; e->path; ++e)
		if (path == e->path && (!e->method || method == e->method))
			return true;

	return false;
}

void ControlServer::serveStatic(IO::TCPServerConnection &c, const std::string &path)
{
#ifdef HASWEBVIEWER
	std::string file = (path == "/") ? "control/index.html" : "control" + path;

	auto it = WebDB::files.find(file);
	if (it == WebDB::files.end())
		it = WebDB::files.find(path.substr(1));

	if (it != WebDB::files.end())
	{
		const WebDB::FileData &f = it->second;
		ResponseRaw(c, f.mime_type, (char *)f.data, f.size, true, std::string(f.mime_type) != "text/html");
		return;
	}
#endif
	HTTPServer::Request(c, path, false);
}

void ControlServer::Request(IO::TCPServerConnection &c, const IO::HTTPRequest &r, bool accept_gzip)
{
	const std::string path = r.path();
	const bool authenticated = !core.authRequired() || (c.is_local && core.hasPassword()) || checkSession(r.cookie);

	if (r.method == "POST" && !sameOrigin(r))
	{
		sendError(c, "cross-origin request rejected", 403);
		return;
	}

	// the bundled frontend, served before the API so it never needs a session
	if (r.method == "GET" && path.compare(0, 5, "/api/") != 0)
	{
		serveStatic(c, path);
		return;
	}

	// One gate for everything below, so no endpoint can end up public by being
	// written above it. An unknown path answers as a private one would.
	if (!authenticated && !isPublic(path, r.method))
	{
		sendError(c, "authentication required", 401);
		return;
	}

	if (path == "/api/status")
	{
		sendStatus(c, authenticated);
	}
	else if (path == "/api/setup" && r.method == "POST")
	{
		if (!core.authRequired())
			sendError(c, "authentication disabled in local mode", 403);
		else if (core.hasPassword())
			sendError(c, "password already set", 403);
		else if (r.body.length() < 6)
			sendError(c, "password needs at least 6 characters");
		else
		{
			core.setPassword(r.body);
			setExtraHeader("Set-Cookie: aiscontrol=" + createSession() + cookieAttributes());
			sendOK(c);
		}
	}
	else if (path == "/api/login" && r.method == "POST")
	{
		int wait = 0;

		if (!core.authRequired())
			sendError(c, "authentication disabled in local mode", 403);
		else if (!core.hasPassword())
			sendError(c, "no password set", 403);
		else if (loginBlocked(wait))
			sendError(c, "too many attempts, retry in " + std::to_string(wait) + "s", 429);
		else if (core.verifyPassword(r.body))
		{
			loginSucceeded();
			setExtraHeader("Set-Cookie: aiscontrol=" + createSession() + cookieAttributes());
			sendOK(c);
		}
		else
		{
			loginFailed();
			sendError(c, "invalid password", 401);
		}
	}
	else if (path == "/api/logout" && r.method == "POST")
	{
		destroySession(r.cookie);
		setExtraHeader("Set-Cookie: aiscontrol=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict");
		sendOK(c);
	}
	else if (path == "/api/password" && r.method == "POST")
	{
		if (r.body.length() < 6)
			sendError(c, "password needs at least 6 characters");
		else
		{
			core.setPassword(r.body);
			destroyAllSessions();
			closeAllSSE();
			setExtraHeader("Set-Cookie: aiscontrol=" + createSession() + cookieAttributes());
			sendOK(c);
		}
	}
	else if (path == "/api/config" && r.method == "GET")
	{
		try
		{
			Response(c, "application/json", core.getConfig(), accept_gzip);
		}
		catch (const std::exception &e)
		{
			sendError(c, e.what(), 500);
		}
	}
	else if (path == "/api/config" && r.method == "POST")
	{
		std::string error;
		if (core.setConfig(r.body, error))
			sendOK(c);
		else
			sendError(c, error);
	}
	else if (path == "/api/legacy_config" && r.method == "GET")
	{
		std::string content;
		if (core.readLegacyConfig(content))
			Response(c, "application/json", content, accept_gzip);
		else
			sendError(c, "no previous configuration found", 404);
	}
	else if (path == "/api/engine" && r.method == "POST")
	{
		std::string action = r.body;
		Util::Convert::toLower(action);

		if (action == "start")
			core.startEngine();
		else if (action == "stop")
			core.stopEngine();
		else if (action == "restart")
			core.restartEngine();
		else
		{
			sendError(c, "unknown action, use start/stop/restart");
			return;
		}
		sendOK(c);
	}
	else if (path == "/api/devices" && r.method == "GET")
	{
		Response(c, "application/json", core.getDeviceListJSON());
	}
	else if (path == "/api/serial" && r.method == "GET")
	{
		Response(c, "application/json", core.getSerialListJSON());
	}
	else if (path == "/api/stream" && r.method == "GET")
	{
		// single log + activity + status stream: browsers cap persistent connections per host
		uint32_t since = (uint32_t)strtoul(r.queryParam("since").c_str(), nullptr, 10);

		upgradeSSE(c, (1u << SSE_ACTIVITY) | (1u << SSE_STATUS) | (1u << SSE_LOG), "log", [since]() -> std::vector<std::string>
				   { return Logger::getInstance().getBacklogJSON(25, since); });

		status_state = STATUS_UNSENT;
	}
	else
	{
		HTTPServer::Request(c, path, false);
	}
}
