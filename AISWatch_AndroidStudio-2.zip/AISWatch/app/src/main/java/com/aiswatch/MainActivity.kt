package com.aiswatch

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.util.Log
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * AIS Watch 메인 액티비티
 * - USB 권한 요청
 * - RTL-SDR 장치 연결
 * - WebView로 웹앱 표시 (localhost:8100)
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "AISWatch-Main"
        private const val ACTION_USB_PERMISSION = "com.aiswatch.USB_PERMISSION"
    }

    private lateinit var webView: WebView
    private lateinit var driver: RtlSdrDriver
    private lateinit var dataStore: AISDataStore
    private var httpServer: AISHttpServer? = null

    /* NMEA 수집 스레드 */
    private var pollThread: Thread? = null
    @Volatile private var running = false

    /* USB 권한 응답 BroadcastReceiver */
    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (ACTION_USB_PERMISSION == intent.action) {
                val device: UsbDevice? = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted && device != null) {
                    Log.i(TAG, "USB 권한 허용: ${device.deviceName}")
                    startAIS(device)
                } else {
                    showError("USB 권한이 거부되었습니다.\n설정 → 앱 → AIS Watch → 권한에서 허용해주세요.")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        driver    = RtlSdrDriver(this)
        dataStore = AISDataStore()

        setupWebView()
        startHttpServer()
        connectRtlSdr()

        registerReceiver(usbReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            RECEIVER_NOT_EXPORTED
        )
    }

    /* ─── WebView 설정 ──────────────────────────────── */
    private fun setupWebView() {
        webView = findViewById(R.id.webView)
        webView.settings.apply {
            javaScriptEnabled     = true
            domStorageEnabled     = true
            allowFileAccess       = true
            loadsImagesAutomatically = true
            mixedContentMode      = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient   = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                Log.i(TAG, "WebView 로드 완료: $url")
            }
        }
        /* 앱 내장 웹앱 로드 */
        webView.loadUrl("http://localhost:8100")
    }

    /* ─── HTTP 서버 시작 ────────────────────────────── */
    private fun startHttpServer() {
        try {
            httpServer = AISHttpServer(this, dataStore, 8100)
            httpServer!!.start()
            Log.i(TAG, "HTTP 서버 시작: http://localhost:8100")
        } catch (e: Exception) {
            Log.e(TAG, "HTTP 서버 시작 실패: ${e.message}")
        }
    }

    /* ─── RTL-SDR 연결 ──────────────────────────────── */
    private fun connectRtlSdr() {
        val device = driver.findDevice()
        if (device == null) {
            showGuide("RTL-SDR 동글이 감지되지 않습니다.\n" +
                "USB-C OTG 케이블로 동글을 연결한 후\n'재연결' 버튼을 누르세요.")
            return
        }

        if (driver.hasPermission(device)) {
            startAIS(device)
        } else {
            /* USB 권한 요청 */
            val pi = PendingIntent.getBroadcast(
                this, 0,
                Intent(ACTION_USB_PERMISSION).setPackage(packageName),
                PendingIntent.FLAG_IMMUTABLE
            )
            val usbManager = getSystemService(USB_SERVICE) as UsbManager
            usbManager.requestPermission(device, pi)
            Toast.makeText(this, "RTL-SDR USB 권한을 요청합니다...", Toast.LENGTH_LONG).show()
        }
    }

    /* ─── AIS 수신 시작 ─────────────────────────────── */
    private fun startAIS(device: UsbDevice) {
        /* ppm 오차: 기기마다 다름 (0=자동, 필요시 설정에서 조정) */
        val ppm = getSharedPreferences("aiswatch", MODE_PRIVATE).getInt("ppm", 0)

        if (!driver.open(device, ppm)) {
            showError("RTL-SDR 장치를 열 수 없습니다.\n장치를 다시 연결하고 시도해주세요.")
            return
        }

        Toast.makeText(this, "✅ AIS 수신 시작! (${driver.deviceName()})", Toast.LENGTH_SHORT).show()

        /* NMEA 폴링 스레드 시작 */
        running = true
        pollThread = Thread {
            Log.i(TAG, "NMEA 폴링 시작")
            while (running) {
                try {
                    val nmea = driver.pollNmea()
                    if (nmea != null && nmea.isNotEmpty()) {
                        dataStore.processNmea(nmea)
                    } else {
                        Thread.sleep(5)
                    }
                } catch (_: InterruptedException) { break }
                catch (e: Exception) { Log.e(TAG, "폴링 오류: ${e.message}") }
            }
            Log.i(TAG, "NMEA 폴링 종료")
        }.also { it.isDaemon = true; it.start() }
    }

    /* ─── UI 헬퍼 ──────────────────────────────────── */
    private fun showGuide(msg: String) {
        runOnUiThread {
            AlertDialog.Builder(this)
                .setTitle("⚓ AIS Watch")
                .setMessage(msg)
                .setPositiveButton("재연결") { _, _ -> connectRtlSdr() }
                .setNegativeButton("닫기", null)
                .show()
        }
    }

    private fun showError(msg: String) {
        runOnUiThread {
            AlertDialog.Builder(this)
                .setTitle("⚠ 오류")
                .setMessage(msg)
                .setPositiveButton("재시도") { _, _ -> connectRtlSdr() }
                .setNegativeButton("닫기", null)
                .show()
        }
    }

    /* ─── 생명주기 ──────────────────────────────────── */
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        pollThread?.interrupt()
        driver.close()
        httpServer?.stop()
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
    }
}
