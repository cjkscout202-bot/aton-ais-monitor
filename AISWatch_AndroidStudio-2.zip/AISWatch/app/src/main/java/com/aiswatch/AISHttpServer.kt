package com.aiswatch

import android.content.Context
import android.util.Log
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream

/**
 * AIS Watch 내장 HTTP 서버 (NanoHTTPD 기반)
 * 포트 8100에서 웹앱과 REST API 제공
 */
class AISHttpServer(
    private val context: Context,
    private val dataStore: AISDataStore,
    port: Int = 8100
) : NanoHTTPD(port) {

    companion object {
        private const val TAG = "AISWatch-HTTP"
    }

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri

        return try {
            when {
                uri == "/" || uri == "/index.html" -> serveWebApp()
                uri == "/data.json"               -> serveData()
                uri.startsWith("/history/")        -> serveHistory(uri)
                uri.startsWith("/msg6/")           -> serveMsg6(uri)
                uri.startsWith("/msg8/")           -> serveMsg8(uri)
                else -> newFixedLengthResponse(
                    Response.Status.NOT_FOUND, MIME_PLAINTEXT, "404 Not Found"
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "serve 오류: ${e.message}")
            newFixedLengthResponse(
                Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "500 Error: ${e.message}"
            )
        }
    }

    /** 웹앱 HTML 제공 (assets/index.html) */
    private fun serveWebApp(): Response {
        val html = context.assets.open("index.html")
            .bufferedReader(Charsets.UTF_8).readText()
        return newFixedLengthResponse(Response.Status.OK, "text/html;charset=UTF-8", html)
    }

    /** /data.json — 실시간 데이터 */
    private fun serveData(): Response {
        val json = dataStore.toDataJson()
        return jsonResponse(json)
    }

    /** /history/{mmsi}.json */
    private fun serveHistory(uri: String): Response {
        val mmsi = uri.removePrefix("/history/").removeSuffix(".json").trim()
        val json = JSONObject().apply {
            put("mmsi", mmsi)
            put("history", dataStore.getHistory(mmsi))
        }
        return jsonResponse(json.toString())
    }

    /** /msg6/{mmsi}.json */
    private fun serveMsg6(uri: String): Response {
        val mmsi = uri.removePrefix("/msg6/").removeSuffix(".json").trim()
        val json = JSONObject().apply {
            put("mmsi", mmsi)
            put("records", dataStore.getMsg6(mmsi))
        }
        return jsonResponse(json.toString())
    }

    /** /msg8/{mmsi}.json */
    private fun serveMsg8(uri: String): Response {
        val mmsi = uri.removePrefix("/msg8/").removeSuffix(".json").trim()
        val json = JSONObject().apply {
            put("mmsi", mmsi)
            put("records", dataStore.getMsg8(mmsi))
        }
        return jsonResponse(json.toString())
    }

    private fun jsonResponse(json: String): Response {
        val r = newFixedLengthResponse(
            Response.Status.OK, "application/json;charset=UTF-8", json
        )
        r.addHeader("Access-Control-Allow-Origin", "*")
        return r
    }
}
