package com.aiswatch

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/**
 * AIS 데이터 파싱 및 저장소
 * ais_server_v6.py의 파싱 로직을 Kotlin으로 이식
 */
class AISDataStore {

    companion object {
        private const val TAG = "AISWatch-Parser"
        private const val AIS_CHARSET = "@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_ !\"#\$%&'()*+,-./0123456789:;<=>?"

        private val EPFD = mapOf(
            0 to "0-미정의", 1 to "1-GPS", 2 to "2-GLONASS",
            3 to "3-GPS+GLONASS", 4 to "4-Loran-C", 5 to "5-Chayka",
            6 to "6-통합항법", 7 to "7-측량값", 8 to "8-Galileo", 15 to "15-내부GNSS"
        )

        private val ATON_KO = mapOf(
            0 to "미지정", 1 to "기준점", 2 to "레이콘",
            3 to "고정구조물(해상)", 5 to "단일등", 6 to "섹터등",
            7 to "도등(전방등)", 8 to "도등(후방등)",
            9 to "방위표지(북)", 10 to "방위표지(동)", 11 to "방위표지(남)", 12 to "방위표지(서)",
            13 to "측면표지(좌현)", 14 to "측면표지(우현)",
            17 to "고립장해표지", 18 to "안전수역표지", 19 to "특수표지",
            20 to "방위부표(북)", 21 to "방위부표(동)", 22 to "방위부표(남)", 23 to "방위부표(서)",
            24 to "측면부표(좌현)", 25 to "측면부표(우현)",
            28 to "고립장해부표", 29 to "안전수역부표", 30 to "특수부표",
            31 to "등선/LANBY/해양구조물"
        )
    }

    /* ─── 데이터 저장소 ─────────────────────────────── */
    val vessels      = ConcurrentHashMap<String, JSONObject>()
    val atons        = ConcurrentHashMap<String, JSONObject>()
    val atonHistory  = ConcurrentHashMap<String, ArrayDeque<JSONObject>>()
    val msg6Data     = ConcurrentHashMap<String, ArrayDeque<JSONObject>>()
    val msg8Data     = ConcurrentHashMap<String, ArrayDeque<JSONObject>>()
    val nmeaLog      = ArrayDeque<JSONObject>()

    /* ─── 수신 통계 ──────────────────────────────────── */
    val totalSentences = AtomicLong(0)
    val totalVessels   = AtomicLong(0)
    val totalAtons     = AtomicLong(0)
    val totalMsg6      = AtomicLong(0)
    val totalMsg8      = AtomicLong(0)
    var lastRxTime     = 0L
    val startTime      = System.currentTimeMillis()
    val rxWindow       = ArrayDeque<Long>()

    private val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private val tf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    /* ─── NMEA 처리 진입점 ───────────────────────────── */
    fun processNmea(line: String) {
        try {
            val parts = line.trim().split(",")
            if (parts.size < 6 || !parts[0].startsWith("!AIVDM")) return

            totalSentences.incrementAndGet()
            lastRxTime = System.currentTimeMillis()
            synchronized(rxWindow) {
                rxWindow.addLast(lastRxTime)
                while (rxWindow.size > 600) rxWindow.removeFirst()
            }

            val payload = parts[5]
            val fill    = parts.getOrNull(6)?.substringBefore("*")?.toIntOrNull() ?: 0
            val bits    = payloadToBits(payload, fill)
            val mt      = bits(bits, 0, 6)

            val tag = when (mt) {
                1, 2, 3, 5, 18, 24 -> "vessel"
                6  -> "msg6"
                8  -> "msg8"
                21 -> "aton"
                else -> "other"
            }

            addNmea(line, mt, tag)
            parseMessage(bits, mt, line)

            // 오래된 데이터 정리
            cleanExpired()

        } catch (e: Exception) {
            Log.e(TAG, "processNmea 오류: ${e.message}")
        }
    }

    /* ─── 메시지 타입별 파싱 ─────────────────────────── */
    private fun parseMessage(bits: String, mt: Int, raw: String) {
        val mmsi = bits(bits, 8, 38).toString()
        val now  = System.currentTimeMillis() / 1000.0

        when (mt) {
            1, 2, 3 -> {
                val sog = bits(bits, 50, 60) / 10.0
                val lon = bits(bits, 61, 89, signed=true) / 600000.0
                val lat = bits(bits, 89, 116, signed=true) / 600000.0
                val cog = bits(bits, 116, 128) / 10.0
                val hdg = bits(bits, 128, 137)
                val st  = bits(bits, 38, 42)
                if (abs(lat) > 90 || abs(lon) > 180 || (lat == 0.0 && lon == 0.0)) return
                val prev = vessels[mmsi] ?: JSONObject()
                vessels[mmsi] = JSONObject().apply {
                    put("mmsi", mmsi); put("name", prev.optString("name",""))
                    put("lat", lat.round(6)); put("lon", lon.round(6))
                    put("sog", sog.round(1)); put("cog", cog.round(1))
                    put("heading", hdg); put("nav_status", st); put("msg_type", mt)
                    put("ship_type", prev.optInt("ship_type",0))
                    put("destination", prev.optString("destination",""))
                    put("last_seen", now)
                }
                totalVessels.incrementAndGet()
            }

            5 -> {
                if (bits.length < 420) return
                val name = bstr(bits, 112, 20)
                val st   = bits(bits, 232, 240)
                val dest = bstr(bits, 302, 20)
                val obj  = vessels.getOrPut(mmsi) { JSONObject().apply {
                    put("mmsi",mmsi); put("lat",0); put("lon",0)
                    put("sog",0); put("cog",0); put("heading",0)
                    put("nav_status",0); put("msg_type",5); put("last_seen",now)
                }}
                obj.put("name", name); obj.put("ship_type", st); obj.put("destination", dest)
            }

            18 -> {
                val sog = bits(bits, 46, 56) / 10.0
                val lon = bits(bits, 57, 85, signed=true) / 600000.0
                val lat = bits(bits, 85, 112, signed=true) / 600000.0
                val cog = bits(bits, 112, 124) / 10.0
                val hdg = bits(bits, 124, 133)
                if (abs(lat) > 90 || abs(lon) > 180 || (lat == 0.0 && lon == 0.0)) return
                val prev = vessels[mmsi] ?: JSONObject()
                vessels[mmsi] = JSONObject().apply {
                    put("mmsi",mmsi); put("name",prev.optString("name",""))
                    put("lat",lat.round(6)); put("lon",lon.round(6))
                    put("sog",sog.round(1)); put("cog",cog.round(1))
                    put("heading",hdg); put("nav_status",0); put("msg_type",18)
                    put("ship_type",prev.optInt("ship_type",0)); put("destination","")
                    put("last_seen",now)
                }
                totalVessels.incrementAndGet()
            }

            21 -> {
                val atonType = bits(bits, 38, 43)
                val name     = bstr(bits, 43, 20)
                val lon      = bits(bits, 164, 192, signed=true) / 600000.0
                val lat      = bits(bits, 192, 219, signed=true) / 600000.0
                val dimA     = if (bits.length >= 228) bits(bits, 219, 228) else 0
                val dimB     = if (bits.length >= 237) bits(bits, 228, 237) else 0
                val dimC     = if (bits.length >= 243) bits(bits, 237, 243) else 0
                val dimD     = if (bits.length >= 249) bits(bits, 243, 249) else 0
                val epfd     = if (bits.length >= 253) bits(bits, 249, 253) else 0
                val utcSec   = if (bits.length >= 259) bits(bits, 253, 259) else 63
                val offPos   = if (bits.length >= 260) bits(bits, 259, 260) else 0
                val atonStat = if (bits.length >= 268) bits(bits, 260, 268) else 0
                val raim     = if (bits.length >= 269) bits(bits, 268, 269) else 0
                var virtual  = if (bits.length >= 270) bits(bits, 269, 270) else 0
                val nameExt  = if (bits.length > 272) bstr(bits, 272, 14) else ""
                val fullName = (name + nameExt).trim()
                if ("SYNTHETIC" in fullName.uppercase() || "VIRTUAL" in fullName.uppercase()) virtual = 1
                if (abs(lat) >= 91 || abs(lon) >= 181) return
                if (lat == 0.0 && lon == 0.0) return

                val koName = ATON_KO[atonType] ?: "유형$atonType"
                atons[mmsi] = JSONObject().apply {
                    put("mmsi", mmsi); put("name", fullName.ifEmpty { "AtoN-$mmsi" })
                    put("lat", lat.round(6)); put("lon", lon.round(6))
                    put("aton_type", atonType); put("aton_name_ko", koName)
                    put("virtual", virtual == 1); put("off_position", offPos == 1)
                    put("epfd", epfd); put("epfd_name", EPFD[epfd] ?: "EPFD$epfd")
                    put("utc_sec", utcSec); put("raim", raim == 1)
                    put("aton_status", atonStat); put("msg_type", 21)
                    put("last_seen", now)
                    if (dimA+dimB+dimC+dimD > 0) {
                        put("dim_a",dimA); put("dim_b",dimB)
                        put("dim_c",dimC); put("dim_d",dimD)
                    }
                }
                // 수신 이력
                val rec = JSONObject().apply {
                    put("ts", tf.format(Date())); put("ts_full", df.format(Date()))
                    put("lat", lat.round(6)); put("lon", lon.round(6))
                    put("off_position", offPos==1); put("virtual", virtual==1)
                    put("aton_status", atonStat); put("epfd", epfd)
                    put("epfd_name", EPFD[epfd] ?: "EPFD$epfd")
                    put("utc_sec", utcSec); put("raim", raim==1); put("raw", raw)
                }
                atonHistory.getOrPut(mmsi) { ArrayDeque() }.apply {
                    addFirst(rec); while (size > 100) removeLast()
                }
                // 태그 업데이트
                updateNmeaTag(raw, if (virtual==1) "aton_virtual" else "aton_physical")
                totalAtons.incrementAndGet()
            }

            6 -> {
                if (bits.length < 120) return
                val dac  = bits(bits, 72, 82)
                val fi   = bits(bits, 82, 88)
                val atonM = bits(bits, 88, 118).toString()
                val func = bits(bits, 118, 120)
                if (dac != 440 || fi !in listOf(51,55)) return
                if (bits.length < 220) return
                val year=bits(bits,120,134); val month=bits(bits,134,138); val day=bits(bits,138,143)
                val hour=bits(bits,143,148); val min=bits(bits,148,154);  val sec=bits(bits,154,160)
                val dtStr = "%04d-%02d-%02d %02d:%02d:%02d".format(year,month,day,hour,min,sec)
                val latRaw=bits(bits,160,184,signed=true); val lonRaw=bits(bits,184,209,signed=true)
                val latDeg=latRaw/60000.0; val lonDeg=lonRaw/60000.0
                val lantern=bits(bits,209,210); val racon=bits(bits,210,212)
                val battery=bits(bits,212,213); val charger=bits(bits,213,214)
                val solar=bits(bits,214,215); val dataLog=bits(bits,215,217)
                val mainV  = if(bits.length>=228) bits(bits,219,228)/10.0 else null
                val solarV = if(bits.length>=237) bits(bits,228,237)/10.0 else null
                val battV  = if(bits.length>=246) bits(bits,237,246)/10.0 else null
                val aisI   = if(bits.length>=267) bits(bits,255,267)/100.0 else null
                val lantI  = if(bits.length>=279) bits(bits,267,279)/100.0 else null
                val dlI    = if(bits.length>=291) bits(bits,279,291)/100.0 else null
                val chgPos = if(bits.length>=303) bits(bits,291,303)/100.0 else null
                val chgNeg = if(bits.length>=315) bits(bits,303,315)/100.0 else null
                val rec = JSONObject().apply {
                    put("ts",tf.format(Date())); put("ts_full",df.format(Date()))
                    put("fi",fi); put("aton_mmsi",atonM); put("function",func)
                    put("device_dt",dtStr)
                    if(abs(latDeg)<=90) put("lat",latDeg.round(5))
                    if(abs(lonDeg)<=180) put("lon",lonDeg.round(5))
                    put("lantern",lantern); put("racon",racon); put("battery",battery)
                    put("charger",charger); put("solar",solar); put("data_logger",dataLog)
                    mainV?.let{put("main_v",it.round(2))}; solarV?.let{put("solar_v",it.round(2))}
                    battV?.let{put("batt_v",it.round(2))}; aisI?.let{put("ais_i",it.round(2))}
                    lantI?.let{put("lantern_i",it.round(2))}; dlI?.let{put("dl_i",it.round(2))}
                    chgPos?.let{put("chg_pos",it.round(2))}; chgNeg?.let{put("chg_neg",it.round(2))}
                    put("raw",raw)
                }
                msg6Data.getOrPut(atonM) { ArrayDeque() }.apply {
                    addFirst(rec); while(size>50) removeLast()
                }
                totalMsg6.incrementAndGet()
            }

            8 -> {
                if (bits.length < 56) return
                val dac = bits(bits, 40, 50); val fi = bits(bits, 50, 56)
                if (dac != 1 || fi !in listOf(11,31)) return
                if (bits.length < 200) return
                val lonRaw=bits(bits,56,81,signed=true); val latRaw=bits(bits,81,105,signed=true)
                val lonDeg=lonRaw/60000.0; val latDeg=latRaw/60000.0
                val utcDay=bits(bits,106,111); val utcHr=bits(bits,111,116); val utcMin=bits(bits,116,122)
                val windSp = bits(bits,122,129).let{ if(it==127) null else it }
                val windGu = bits(bits,129,136).let{ if(it==127) null else it }
                val windDi = bits(bits,136,145).let{ if(it==360) null else it }
                val airT   = bits(bits,154,165,signed=true).let{ if(it==-1024) null else it/10.0 }
                val humi   = bits(bits,165,172).let{ if(it==101) null else it }
                val press  = bits(bits,182,191)
                val pressV = if(press==511) null else if(press<=401) press+799 else null
                val wlevel = if(bits.length>=213) bits(bits,201,213) else null
                val wlevM  = wlevel?.let{ if(it>=4001) null else (it/100.0)-10.0 }
                val waveH  = if(bits.length>=262) bits(bits,254,262)/10.0 else null
                val waterT = if(bits.length>=314) bits(bits,304,314,signed=true).let{ if(it==501) null else it/10.0 } else null
                val rec = JSONObject().apply {
                    put("ts",tf.format(Date())); put("ts_full",df.format(Date()))
                    put("fi",fi); put("src_mmsi",mmsi)
                    if(abs(latDeg)<=90) put("lat",latDeg.round(5))
                    if(abs(lonDeg)<=180) put("lon",lonDeg.round(5))
                    put("utc","%02d일 %02d:%02d".format(utcDay,utcHr,utcMin))
                    windSp?.let{put("wind_speed",it)}; windGu?.let{put("wind_gust",it)}
                    windDi?.let{put("wind_dir",it)}; airT?.let{put("air_temp",it.round(1))}
                    humi?.let{put("humidity",it)}; pressV?.let{put("pressure",it)}
                    wlevM?.let{put("water_level",it.round(2))}
                    waveH?.let{put("wave_height",it.round(1))}
                    waterT?.let{put("water_temp",it.round(1))}
                    put("raw",raw)
                }
                msg8Data.getOrPut(mmsi) { ArrayDeque() }.apply {
                    addFirst(rec); while(size>50) removeLast()
                }
                totalMsg8.incrementAndGet()
            }
        }
    }

    /* ─── NMEA 로그 ──────────────────────────────────── */
    @Synchronized
    private fun addNmea(line: String, mt: Int, tag: String) {
        nmeaLog.addFirst(JSONObject().apply {
            put("ts", tf.format(Date())); put("raw", line)
            put("mt", mt); put("tag", tag)
        })
        while (nmeaLog.size > 500) nmeaLog.removeLast()
    }

    @Synchronized
    private fun updateNmeaTag(raw: String, tag: String) {
        nmeaLog.firstOrNull { it.optString("raw") == raw }?.put("tag", tag)
    }

    /* ─── 만료 정리 ──────────────────────────────────── */
    private fun cleanExpired() {
        val now = System.currentTimeMillis() / 1000.0
        vessels.entries.removeIf  { now - it.value.optDouble("last_seen",0.0) > 600  }
        atons.entries.removeIf    { now - it.value.optDouble("last_seen",0.0) > 3600 }
    }

    /* ─── API 응답 생성 ──────────────────────────────── */
    fun toDataJson(): String {
        val now = System.currentTimeMillis()
        val rpm = synchronized(rxWindow) {
            rxWindow.count { now - it <= 60_000 }
        }
        return JSONObject().apply {
            put("vessels",    JSONArray(vessels.values.toList()))
            put("atons",      JSONArray(atons.values.toList()))
            put("nmea",       JSONArray(nmeaLog.take(150)))
            put("msg6_count", msg6Data.values.sumOf { it.size })
            put("msg8_count", msg8Data.values.sumOf { it.size })
            put("stats", JSONObject().apply {
                put("ais_catcher_ok",  true)
                put("total_sentences", totalSentences.get())
                put("total_vessels",   totalVessels.get())
                put("total_atons",     totalAtons.get())
                put("total_msg6",      totalMsg6.get())
                put("total_msg8",      totalMsg8.get())
                put("rx_per_min",      rpm)
                put("uptime_sec",      (now - startTime) / 1000)
                put("last_rx",         lastRxTime / 1000.0)
            })
        }.toString()
    }

    fun getHistory(mmsi: String) = JSONArray(atonHistory[mmsi]?.take(50) ?: emptyList<JSONObject>())
    fun getMsg6(mmsi: String)    = JSONArray(msg6Data[mmsi]?.take(50) ?: emptyList<JSONObject>())
    fun getMsg8(mmsi: String)    = JSONArray(msg8Data[mmsi]?.take(50) ?: emptyList<JSONObject>())

    /* ─── AIS 비트 처리 유틸 ─────────────────────────── */
    private fun payloadToBits(payload: String, fill: Int): String {
        val sb = StringBuilder()
        for (c in payload) {
            var v = c.code - 48
            if (v > 39) v -= 8
            v = v.coerceIn(0, 63)
            sb.append(v.toString(2).padStart(6, '0'))
        }
        val s = sb.toString()
        return if (fill > 0 && s.length >= fill) s.dropLast(fill) else s
    }

    private fun bits(b: String, s: Int, e: Int, signed: Boolean = false): Int {
        if (s >= b.length) return 0
        val chunk = b.substring(s, minOf(e, b.length))
        if (chunk.isEmpty()) return 0
        var v = chunk.toInt(2)
        if (signed && chunk[0] == '1') v -= (1 shl chunk.length)
        return v
    }

    private fun bstr(b: String, s: Int, n: Int): String {
        val sb = StringBuilder()
        for (i in 0 until n) {
            val c = bits(b, s + i*6, s + i*6 + 6)
            if (c == 0) break
            if (c in AIS_CHARSET.indices) sb.append(AIS_CHARSET[c])
        }
        return sb.toString().trim('@', ' ')
    }

    private fun Double.round(n: Int): Double {
        val factor = Math.pow(10.0, n.toDouble())
        return Math.round(this * factor) / factor
    }
}
